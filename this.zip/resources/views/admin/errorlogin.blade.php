@extends('admin.layouts.default')

@section('content')

   <div id="mws-error-page">
			<h1>Error <span>404</span></h1>
			<h5>Oopss... this is embarassing, either you tried to access a non existing page, or our server has gone crazy.</h5>
		</div>
	</div>
          
@stop
