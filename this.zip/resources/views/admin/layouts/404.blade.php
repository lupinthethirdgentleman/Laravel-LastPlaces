<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Welcome To Video Resume</title>
		
		{{ HTML::style('css/bootstrap.css') }}	
		{{ HTML::style('css/developer.css') }}	
		{{ HTML::style('css/pnotify.core.css') }}	
		{{ HTML::style('css/checkbox-style.css') }}	
		
		{{ HTML::script('js/jquery-2.1.1.min.js') }}	
		{{ HTML::script('js/bootstrap.min.js') }}	
		
	</head>
	<body class="over-hidden">

	<div id="mws-error-page">
		<h1>Error <span>404</span></h1>dsadsaasas
		<h5>Oopss... this is embarassing, either you tried to access a non existing page, or our server has gone crazy.</h5>
		<p><a href="{{Url::to('admin')}}">click here</a> to go back home</p>
     </div>
 

		
	</body>
</html>