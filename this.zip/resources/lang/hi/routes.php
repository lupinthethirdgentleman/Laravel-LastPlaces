<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Routes
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the routes of the website
    |
    */

    'faqs' => 'me-faqs',
   
);