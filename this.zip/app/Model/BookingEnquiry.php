<?php 
namespace App\Model; 
use Eloquent;
/**
 * Testimonial Model
 */
 
class BookingEnquiry extends Eloquent  {

	
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
 
	protected $table = 'booking_enquiry';
	
	/**
	 * Function for  bind AdminTestimonialDescription model   
	 *
	 * @param null 
	 *
	 * return query
	 */	
	
		
}// end Testimonial class
