<?php 
namespace App\Model; 
use Eloquent;
/**
 * FaqDescription Model
 */
class FaqDescription extends Eloquent {

	
/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'faq_descriptions';

	
}// end FaqDescription class
