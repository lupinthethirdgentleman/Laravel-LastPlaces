<?php 
namespace App\Model; 
use Eloquent;
/**
 * Menu Model
 */
class Menu extends Eloquent {

	
/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'menus';

	
}// end Menu class
