<?php
namespace App\Model; 
use Eloquent;
/**
 * NewsletterTemplate Model
 */
class NewsLetterTemplate extends Eloquent {

	
/**
 * The database collection used by the model.
 *
 * @var string
 */
	protected $table = 'newsletter_templates';

}//end NewsletterTemplate class
