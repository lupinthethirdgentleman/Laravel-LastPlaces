<?php
namespace App\Model; 
use Eloquent;

/**
 * EmailLog Model
 */
class EmailLog extends Eloquent  {
	
/**
 * The database table used by the model.
 *
 */
 
 protected $table = 'email_logs';
 
		
}// end EmailLog class
