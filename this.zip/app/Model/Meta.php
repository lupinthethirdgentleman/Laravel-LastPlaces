<?php
namespace App\Model; 
use Eloquent;
/**
 * Meta Model
 */
class Meta extends Eloquent  {

/**
 * The database collection used by the model.
 *
 */
 protected $table = 'metas';
 
}// end Meta class
