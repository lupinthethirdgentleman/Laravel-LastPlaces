<?php 
namespace App\Model; 
use Eloquent;

/**
 * Country Model
 */
 
class TripMapDetail extends Eloquent  {
	
/**
 * The database table used by the model.
 *
 * @var string
 */
 
	protected $table = 'trip_map_detail';
	
	

}// end Media class
