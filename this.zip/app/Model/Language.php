<?php 
namespace App\Model; 
use Eloquent;
/**
 * Language Model
 */
class Language extends Eloquent {

	
/**
 * The database table used by the model.
 *
 */
	protected $table = 'languages';

}// end Language class
