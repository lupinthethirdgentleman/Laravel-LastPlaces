<?php
namespace App\Model; 
use	Eloquent;
/**
 * Setting Model
 */
class Setting extends Eloquent {

/**
 * The database collection used by the model.
 *
 * @var string
 */
	protected $table = 'settings';
	


}// end Setting class
