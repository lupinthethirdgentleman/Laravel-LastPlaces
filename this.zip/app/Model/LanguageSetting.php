<?php 
namespace App\Model; 
use Eloquent;
/**
 * LanguageSetting Model
 */
class LanguageSetting extends Eloquent {

	
/**
 * The database table used by the model.
 *
 */
	protected $table = 'language_settings';

}// end LanguageSetting class
