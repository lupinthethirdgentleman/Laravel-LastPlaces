<?php
namespace App\Model; 
use Eloquent;
/**
 * Contact Model
 */
 
class Contact extends Eloquent   {
	
	/**
	 * The database collection used by the model.
	 *
	 * @var string
	 */
 
protected $table = 'contact_us';
} // end Contact class
