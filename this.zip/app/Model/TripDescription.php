<?php
namespace App\Model; 
use Eloquent;

/**
 * CmsDescription Model
 */
class TripDescription extends Eloquent{

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'trips_description';
	
	/**
	 * function for find result from database 
	 *
	 * @param null
	 * 
	 * @return array
	 */		
	
	
}// end CmsDescription class