<?php 
namespace App\Model; 
use Eloquent;

/**
 * EmailTemplate Model
 */
 
class EmailTemplate extends Eloquent {

	
/**
 * The database table used by the model.
 */
	protected $table = 'email_templates';

	
}// end EmailTemplate class
