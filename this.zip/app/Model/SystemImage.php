<?php 
namespace App\Model; 
use Eloquent;

/**
 * SystemDoc Model
 */
 
class SystemImage extends Eloquent  {
	
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
 
	protected $table = 'system_images';
	
}// end SystemDoc class
