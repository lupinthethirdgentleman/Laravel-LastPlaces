<?php 
namespace App\Model; 
use Eloquent;

/**
 * MetaDescription Model
 */
class MetaDescription extends Eloquent {

/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'metas_descriptions';
	
}// end MetaDescription class
