<?php 
namespace App\Model; 
use Eloquent;
/**
 * NewsLetter Model
 */
class NewsLetter extends Eloquent {

	
/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'newsletters';

}//end NewsLetter class