<?php 
namespace App\Model; 
use Eloquent;

/**
 * SystemDoc Model
 */
 
class SystemDoc extends Eloquent  {
	
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
 
	protected $table = 'system_documents';
	
}// end SystemDoc class
