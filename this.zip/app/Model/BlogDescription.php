<?php
namespace App\Model; 
use Eloquent;

	/**
	 * BlogDescription Model
	 */
	 
class BlogDescription extends Eloquent{

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'blog_descriptions';
	
	
}// end BlogDescription class
