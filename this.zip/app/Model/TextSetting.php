<?php
namespace App\Model; 
use Eloquent;
/**
 * TextSetting Model
 */
class TextSetting extends Eloquent {

/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'textsettings';
	
	//public $timestamps = false;
	


}// end TextSetting class
