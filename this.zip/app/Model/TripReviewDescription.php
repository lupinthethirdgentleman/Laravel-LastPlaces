<?php 
namespace App\Model; 
use Eloquent;
/**
 * Testimonial Model
 */
 
class TripReviewDescription extends Eloquent  {

	
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
 
	protected $table = 'trip_review_description';
	
	/**
	 * Function for  bind AdminTestimonialDescription model   
	 *
	 * @param null 
	 *
	 * return query
	 */	

	
		
}// end Testimonial class
