<?php 
namespace App\Model; 
use Eloquent;

/**
 * DropDownDescription Model
 */
 
class DropDownDescription extends Eloquent {

/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'dropdown_manager_descriptions';
	
}// end DropDownDescription class
