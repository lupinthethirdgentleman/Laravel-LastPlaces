<?php
namespace App\Model; 
use Eloquent;

	/**
	 * BlogDescription Model
	 */
	 
class BlogComments extends Eloquent{

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'blog_comments';
	
	
}// end BlogDescription class
