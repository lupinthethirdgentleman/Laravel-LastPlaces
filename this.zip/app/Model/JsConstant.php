<?php
namespace App\Model; 
use Eloquent;
/**
 * TextSetting Model
 */
class JsConstant extends Eloquent {

/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'textsettings';
	
	//public $timestamps = false;
	


}// end TextSetting class
