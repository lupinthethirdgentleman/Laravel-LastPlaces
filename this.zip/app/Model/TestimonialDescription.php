<?php 
namespace App\Model; 
use Eloquent;

/**
 * TestimonialDescription Model
 */
 
class TestimonialDescription extends Eloquent {

/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'testimonial_descriptions';
	
}// end TestimonialDescription class
