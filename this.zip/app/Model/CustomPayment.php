<?php
namespace App\Model; 
use Eloquent;
/**
 * Ads Model
 */
class CustomPayment extends Eloquent {

/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'custom_payment';

	
}// end Ads class
