<?php 
namespace App\Model; 
use Eloquent;

/**
 * Subscriber Model
 */
 
class Subscriber extends Eloquent   {
	
/**
 * The database table used by the model.
 *
 * @var string
 */
	protected $table = 'subscribers';
	
} // end Subscriber class
