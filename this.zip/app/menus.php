<?php 
Config::set("pricing", array());
?> 
<?php 
Config::set("menus", array("how-it-works"=>"How it Works",
"jobs"=>"Search for Jobs",
"brochures"=>"Personal Brochure Samples",
"resources"=>"Resources",
"free-download"=>"Free Downloads",
"video-vault"=>"Video Vault",
"blog"=>"Blogdasd",
"tips"=>"Tips",
"faqs"=>"FAQ's",
"pricing"=>"Pricing",
));
